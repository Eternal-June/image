title: 华为云ModelArts 调研/论文阅读分享
speaker: 刘志雄
js:
    - https://www.echartsjs.com/asset/theme/shine.js
prismTheme: solarizedlight
plugins:
        - echarts

<slide class="bg-black-blue aligncenter" image="https://cn.bing.com/az/hprichbg/rb/RainierDawn_EN-AU3730494945_1920x1080.jpg .dark">论文阅读分享{.text-landing.text-shadow}

['dark', 'coy', 'funky', 'okaidia', 'tomorrow', 'solarizedlight', 'twilight']

By 刘志雄 {.text-intro}

<slide  image="https://raw.githubusercontent.com/Eternal-June/image/main/image-20221128203502690.png .light">

## Colorful

:::flexblock {.border.blink} 

## .bg-red {..bg-red}

\#c23

:::

:::{.aligncenter}

# Simple CSS Alignments

Put content wherever you want.
:::

:::footer
Footer: logo, credits... (.alignleft) {.alignleft}

[:fa-twitter: @username .alignright](){.alignright}

:::

:::header
Header (logo)    :.alignright:{.alignright}
:::





<slide  image="https://raw.githubusercontent.com/Eternal-June/image/main/Corporate-Culture-Development-Cooperation-Business-Geometry-Ppt-Background-transformed.jpeg .d">

`.text-cols (2 columns)`

:::div {.text-cols}

**Why WebSlides?** There are excellent presentation tools out there. WebSlides is about sharing content, essential features, and clean markup. **Each parent &lt;slide&gt;**  in the #webslides element is an individual slide.

**WebSlides help you build a culture of innovation and excellence**. When you're really passionate about your job, you can change the world. How to manage a design-driven organization? Leadership through usefulness, openness, empathy, and good taste.

:::

:::flexblock {.metrics}

:![image-20221128192954273](https://raw.githubusercontent.com/Eternal-June/image/main/image-20221128192954273.png):

Call us at 555.345.6789

----

:![image-20221128192954273](https://raw.githubusercontent.com/Eternal-June/image/main/image-20221128192954273.png):

@username

----

![image-20221128192758968](https://raw.githubusercontent.com/Eternal-June/image/main/image-20221128192758968.png)
Send us an email
:::







<slide class="bg-black-blue aligncenter" image="https://cn.bing.com/az/hprichbg/rb/RainierDawn_EN-AU3730494945_1920x1080.jpg .dark">

# CLIPTexture: Text-Driven Texture Synthesis

人工智能能否根据人类的语言控制，创造出具有艺术价值的肌理?现有的纹理合成方法需要示例纹理输入。然而，在许多实际情况下，用户没有令人满意的纹理，但通过简单的草图和口头描述告诉设计师他们的需求。本文提出了一种新的基于CLIP的纹理合成框架，该框架将纹理合成问题建模为一个优化过程，通过最小化输入图像与文本提示符在潜在空间中的距离来实现文本驱动的纹理合成。该方法即使在不可见域之间也能成功地实现零镜头图像处理。我们使用TextureNet和Diffvg两种不同的优化方法实现纹理合成，展示了CLIPTexture的通用性。大量的实验证实，与现有的基线相比，我们的方法具有鲁棒性和优越的操作性能。‘



<slide class="bg-black-blue aligncenter" image="https://cn.bing.com/az/hprichbg/rb/RainierDawn_EN-AU3730494945_1920x1080.jpg .dark">

1. 我们提出了一个基于clip的纹理合成框架，该框架将模式生成问题建模为一个优化过程，并通过最小化输出和提示符之间的语义差异来生成纹理。据我们所知，我们的方法是第一个文本驱动的纹理合成方法。
2. 本文使用Diffvg和我们提出的轻量级网络texturenet两种优化方法来证明我们的框架的有效性和通用性。该优化器还可以灵活地与其他图像翻译网络替换，以达到不同的效果。
3. 我们的渐进优化策略是启发式的。有效解决了优化过程中图像失真的问题，实现了无需任何预训练GAN的域转移。

![image-20221104121141298](https://raw.githubusercontent.com/Eternal-June/image/main/image-20221104121141298.png)

<slide class="bg-black-blue aligncenter" image="https://cn.bing.com/az/hprichbg/rb/RainierDawn_EN-AU3730494945_1920x1080.jpg .light">

视觉语言任务包括基于语言的图像检索、图像字幕、视觉问题回答和文本引导合成等。在CLIP出现之前，为了解决这些任务，需要学习一个跨模态的视觉和语言表示[3,4,6,29,39,40]，通常是通过训练一个转换器[43]

以前的纹理合成方法需要示例图像输入，但在许多实际情况下，用户无法找到满意的纹理，而是通过简单的草图和口头描述告诉设计师自己的需求。为此，我们提出了CLIPTexture，一种零镜头文本驱动的纹理合成方法。CLIPTexture可以生成任何大小和内容的纹理，允许通过输入图像和文本描述来控制结果。如图3所示，CLIPTexture不仅可以合成自然界中存在的纹理，还可以拟合抽象概念。







